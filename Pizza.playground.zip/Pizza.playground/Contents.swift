//: Playground - noun: a place where people can play

import Cocoa

class Pizza{
    typealias aMatrix = Array<Array<Int>>
    var matrix = aMatrix()
    var matrixSum = aMatrix()
    var r = 0, c = 0, l = 0, h = 0
 
    init(_ path: String) {
        matrix = readFromFile(path: path)
        matrixSum = matrix
     }
    
    private func readFromFile(path: String) -> aMatrix{
        do {
            let textRead = try String(contentsOfFile: path)
            let stringScanner = Scanner(string: textRead)
            stringScanner.scanInt(&r)
            stringScanner.scanInt(&c)
            stringScanner.scanInt(&l)
            stringScanner.scanInt(&h)
            var arrString =  textRead.components(separatedBy: "\n")
            arrString.removeFirst()
            arrString.removeLast()
            return arrString.map{$0.characters.map{String($0) == "T" ? 1 : 0}}
        } catch {
            print("file \(path) not found")
            return aMatrix()
        }
    }
    
    func matrix2String (_ matrix: Array<Array<Int>>) -> String{
        var output = matrix.description.replacingOccurrences(of: "], ", with: "]\n")
        output = output.replacingOccurrences(of: "[[", with: "[")
        output = output.replacingOccurrences(of: "]]", with: "]")
        return output
    }
    
    var description:String {
        return matrix2String(matrix)
    }
    
    func neighborhood() -> aMatrix{
        var temp = matrix
        for i in 0..<temp.count {
            for j in 0..<temp[0].count {
                
            }
        }
        return temp
    }
    
}

var pizza = Pizza("/Users/fms/Desktop/Pizza/small.in")
print(pizza.description, terminator: "\n---------------------\n")
pizza.matrixSum = pizza.neighborhood()
print(pizza.matrix2String(pizza.matrixSum))



